module.exports = [
"[project]/app/product/[slug]/loading.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=app_product_%5Bslug%5D_loading_tsx_4c86ef1b._.js.map