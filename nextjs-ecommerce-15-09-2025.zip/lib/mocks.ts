export type Product= {
    id:number;
    name:string;
    price:number;
    description:string;
    image:string;
    category:string;
}
//create an array of products with image online google link
export const mockProducts:Product[]=[
    {
        id: 1,
        name: "Wireless Headphones",
        price: 59.99,
        description: "High-quality wireless headphones with noise cancellation.",
        image: "https://plus.unsplash.com/premium_photo-1678099940967-73fe30680949?q=80&w=880&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        category: "Electronics"
    },
    {
        id: 2,
        name: "Running Shoes",
        price: 89.99,
        description: "Comfortable and durable running shoes for all terrains.",
        image: "https://images.unsplash.com/photo-1585944672394-4c58a015c1fb?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        category: "Footwear"
    },
    {
        id: 3,
        name: "Smart Watch",
        price: 129.99,
        description: "Track your fitness and stay connected with this smart watch.",
        image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?q=80&w=2072&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        category: "Electronics"
    },
    {
        id: 4,
        name: "Coffee Mug",
        price: 14.99,
        description: "Ceramic coffee mug with a stylish design.",
        image: "https://images.unsplash.com/photo-1605714196241-00bf7a8fe7bb?q=80&w=1074&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        category: "Home & Kitchen"
    }
]