-- AlterTable
ALTER TABLE "public"."Product" ADD COLUMN     "inventory" INTEGER NOT NULL DEFAULT 0;
